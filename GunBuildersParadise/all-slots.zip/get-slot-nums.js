var fileIO = require("./fileIO");

var items = fileIO.readParsed("./items.json");
var locale = fileIO.readParsed("./locale_en.json");
var output = {};
for(var name in items.data){
	var item = items.data[name];
	if(!item._props || !item._props.Slots || item._props.Slots.length <= 0)
		continue;
	var itemName = locale.templates[item._id].Name;
	output[itemName] = {};
	for(var ind in item._props.Slots){
		var slot = item._props.Slots[ind];
		output[itemName][slot._name] = ind;
	}
}
fileIO.write("./all-slots.json", output);